
const path = require('path');
const express = require('express');

const router = express.Router();


const products ={};



router.get('/add-salary', (req, res, next) => {
    res.render('add-salary', {
        pageTitle: "My Store - Add Product"
    })
 
 
});

router.post('/add-salary', (req, res, next) => {


  num = req.body.product;




  if (num >= 400000)
   {
     aftertax=    (num - (num * 0.25));
     }

     else if (num >= 300000)
     {
        aftertax=(num - (num * 0.2));
     }

     else if (num >= 200000)
     {
       aftertax= (num - (num * 0.15));

     }
     else if (num >= 100000)
     {
      aftertax=  (num - (num * 0.10));
     }
    

         products.num=num;
        products.aftertax= aftertax;

  res.redirect('/admin/salary');
 
});



router.get('/salary', (req, res, next) => {
    res.render('salary', {
        pageTitle: "My Store - Products",
        products:products
       
    })
});


module.exports = router;




