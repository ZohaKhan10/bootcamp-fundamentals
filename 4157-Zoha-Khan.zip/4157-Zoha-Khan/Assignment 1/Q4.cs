﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = { 10, 220, 3, 47, 5, 6 };

            int max = arr[0];

            for(int i=0; i<arr.Length; i++)
            {
                if (arr[i] > max)
                    max = arr[i];
            }
            Console.WriteLine("the largest element of array is : " + max);
            Console.ReadLine();
        }
    }
}
