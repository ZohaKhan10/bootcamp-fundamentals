﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BonusQuestion
{
    class Program
    {
        static void Main(string[] args)
        {

            string str, reverse = "";

            Console.WriteLine("Entere a string");
           str= Console.ReadLine();
            for(int i= str.Length-1; i>=0; i--)
            {
                reverse = reverse + str[i];
            }

            if (reverse == str)
            {
                Console.WriteLine("It is a palindrome");
                Console.ReadLine();
            }

            else
                Console.WriteLine("it is not a palindrome");
            Console.ReadLine();
        }

    }
}
