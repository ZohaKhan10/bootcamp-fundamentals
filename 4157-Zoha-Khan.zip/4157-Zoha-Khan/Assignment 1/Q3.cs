﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {

            string val1,val2;
            int res1,res2;

            Console.WriteLine("Enter the first number ");
            val1 = Console.ReadLine();
            res1 = Convert.ToInt32(val1);
            Console.WriteLine("Enter the second number ");
            val2 = Console.ReadLine();
            res2 = Convert.ToInt32(val2);

            int res = res1 + res2;
            Console.WriteLine("The sum of both elements is : " + res);
            Console.ReadLine();
        }
    }
}
