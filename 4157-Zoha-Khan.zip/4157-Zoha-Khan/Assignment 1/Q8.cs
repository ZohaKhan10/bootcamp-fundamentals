﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q8
{
    class Program
    {
        static void Main(string[] args)
        {
            string val;
            int num = 0;
            Console.WriteLine("Enter the number :");
            val = Console.ReadLine();
            int value = Convert.ToInt32(val);

            for (int i = 1; i <= value; i++)
            {
                if ((value % i) == 0)
                {
                    num++;
                }

            }

            if (num == 2)
            {
                Console.WriteLine("It is a prime number");
            }
            else
                Console.WriteLine("It is not a prime number");

            Console.ReadLine();

        }
    }
}
