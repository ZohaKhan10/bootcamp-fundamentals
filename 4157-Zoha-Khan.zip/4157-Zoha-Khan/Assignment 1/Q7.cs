﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q7
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = { 2, 5, 77, 3, 1, 33 };
            Console.WriteLine("The elements at odd position in the list are : ");
            for(int i = 0; i < arr.Length; i++)
            {
                if((i % 2) !=0)
                {
                    Console.WriteLine(arr[i] );
                }
            }
            Console.ReadLine();

        }
    }
}
