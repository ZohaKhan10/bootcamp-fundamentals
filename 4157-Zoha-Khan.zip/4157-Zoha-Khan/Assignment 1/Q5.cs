﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 4, 5, 6 };

            string val;
            int res;
            int count = 0; 
            Console.WriteLine("Enter the number you want to check");
            val = Console.ReadLine();
            res = Convert.ToInt32(val);

            for (int i = 0; i < arr.Length; i++)
            {
                if (res == arr[i])
                {
                    count++;
                }

            }
                if (count>0)
                {
                    Console.WriteLine("yes the element exist in the list");
                    Console.ReadLine();

                }
            else
            {
                Console.WriteLine("the element does not exist");
                Console.ReadLine();
            }


        }
        }
    }
