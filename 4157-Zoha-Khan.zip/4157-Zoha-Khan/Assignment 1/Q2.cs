﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {

            string value;
            Console.WriteLine("Enter a number");
           value=Console.ReadLine();

           int Number= Convert.ToInt32(value);

            if(Number %2==0)
            {
                Console.WriteLine("The number is even");
                Console.ReadLine();
            }

            else
            {
                Console.WriteLine("Number is odd");
                Console.ReadLine();
            }

        }
    }
}
