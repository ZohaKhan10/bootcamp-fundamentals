﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q6
{
    class Program
    {
        static void Main(string[] args)
        { 

            string val;
            Console.WriteLine("Enter the number for which you want the multiplication table: ");
            val=Console.ReadLine();

            int num=Convert.ToInt32(val);

            for(int i=1; i<=10; i++)
            {
                Console.WriteLine( num +" * "+ i + " = " + num*i  );
            }
            Console.ReadLine();



        }
    }
}
