﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[7];
       

           
            Console.WriteLine("Read elements of array");
            for (int i = 0; i < 7; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            int len = arr.Length;
         
            for (int i = 0; i < len; i++)
           {
               if(Prime(arr[i]))
                    {

                    for(int j=i; j<len-1; j++)
                        {
                        arr[j]=arr[j+1];
                    }
                   i--;
                    len--;
                    
                }
            }
             Console.WriteLine("array after removing prime numbers is:");
            for (int i = 0; i < len; i++)
                {
                Console.WriteLine(arr[i]);
            }

            Console.ReadLine();
            }
            static bool Prime(int num)
                {
                   for (int i = 2; i < num; i++)
                    {
                    if(num %i ==0)
                        {
                        return false;
                    }

                }
                   return true;

            }

        


        }
    }

