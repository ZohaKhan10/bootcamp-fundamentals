﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q9
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = { 1, 3, 5, 10 };
            int len1 = arr1.Length;
            int i = 0, j = 0, k = 0;
            int[] arr2 = { 5, 7, 9, 10 };
            int len2 = arr2.Length;
            int[] arr3 = new int[len1 + len2];

            for (int y = 0; y < len1; y++)
            {
                for (int m = y + 1; m < len1; m++)
                {
                    if (arr2[y] > arr2[m])
                    {
                        int temp = arr2[y];
                        arr2[y] = arr2[m];
                        arr2[m] = temp;
                    }
                }

            }
            while (i < len1 && j < len2)
            {

                if (arr1[i] < arr2[j])
                    arr3[k++] = arr1[i++];
                else
                    arr3[k++] = arr2[j++];
            }


            while (i < len1)
                arr3[k++] = arr1[i++];


            while (j < len2)
                arr3[k++] = arr2[j++];

            Console.Write("Array after merging : ");
            for (int l = 0; l < len1 + len2; l++)
                Console.Write(arr3[l] + " ");

            Console.ReadLine();
        }
    }
}
