﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q10
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = { 1, 3, 2, 4, 7, 6, 9, 10 };
            int len = arr1.Length;
            int[] arr2 = new int[len];
            int index = 0;

            for (int i = 0; i < len; i++)
            {
                if (arr1[i] % 2 == 0)
                {
                    arr2[index] = arr1[i];
                    index++;
                }
            }
            for (int i = 0; i < len; i++)
            {
                if (arr1[i] % 2 != 0)
                {
                    arr2[index] = arr1[i];
                    index++;
                }
            }
            Console.WriteLine("The array after separation of even and odd numbers is :");

            for (int i = 0; i < len; i++)
            {
                Console.Write(arr2[i] + " ");
            }
            Console.ReadLine();
        }
    }
}
