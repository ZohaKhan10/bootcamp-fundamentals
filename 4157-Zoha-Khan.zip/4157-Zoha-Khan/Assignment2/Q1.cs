﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {

            int sum = 0;
            int product = 1;
            int[] arr = new int[10];
            Console.WriteLine("Input elements of array");
            for (int i = 0; i < 10; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Elements of array are:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(arr[i]);
            }

            for (int i = 0; i < 10; i++)
            {
                sum = sum + arr[i];
            }

            Console.WriteLine("Sum of Elements in array is:" + sum);


            for (int i = 0; i < 10; i++)
            {
                product = product * arr[i];
            }

            Console.WriteLine("product of Elements in array is:" + product);

            Console.ReadLine();


        }
    }
}
