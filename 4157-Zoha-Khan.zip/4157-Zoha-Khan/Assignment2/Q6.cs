﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    class Program
    {
        static void Main(string[] args)
        {
            string num;
            int positive = 0, negative = 0;
            int sum = 0, sum1 = 0, sum2 = 0;
            float avg;
            Console.WriteLine("How many integers you want to read");
            num = Console.ReadLine();
            int n = Convert.ToInt32(num);
            int[] arr = new int[n];

            Console.WriteLine("Read elements of array");
            for (int i = 0; i < n; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
            {
                if (arr[i] > 0)
                {
                    positive++;
                    sum1 = sum1 + arr[i];
                }
                else
                {

                    negative++;
                    sum2 = sum2 + arr[i];
                }
            }

            
            sum = sum1 + sum2;
            avg = sum / n;


            Console.WriteLine("The number of positive numbers is:" + positive);
            Console.WriteLine("The number of negative numbers is:" + negative);
            Console.WriteLine("The total sum is:" + sum);
            Console.WriteLine("The total average is :" + avg);

            Console.ReadLine();

        }
    }
}
