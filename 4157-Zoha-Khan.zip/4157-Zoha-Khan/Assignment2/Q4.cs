﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            int len = arr.Length;

            Console.WriteLine("Read elements of array");
            for (int i = 0; i < 10; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < len; i++)
            {

                for (int j = i + 1; j < len; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        for (int k = j; k < len - 1; k++)
                        {
                            arr[k] = arr[k + 1];
                        }
                        len--;

                    }
                   
                }
            }
            Console.WriteLine("Array after removing duplicate elements is:");
            for (int i = 0; i < len; i++)
            {
                Console.WriteLine(arr[i]);
            }

            Console.ReadLine();

        }
    }
}
