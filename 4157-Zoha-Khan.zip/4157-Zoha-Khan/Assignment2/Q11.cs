﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            int len = arr.Length;
            int temp;
            Console.WriteLine("Read elements of array");
            for (int i = 0; i < len; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            temp = arr[0];
            arr[0] = arr[len - 1];
            arr[len - 1] = temp;

            Console.WriteLine("Array after swapping:");
            for (int i = 0; i < len; i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.ReadLine();
        }
    }
}
