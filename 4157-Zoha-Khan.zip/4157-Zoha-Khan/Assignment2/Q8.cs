﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q8
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 5, 6, 5, 3, 2 };
            int sum = 0;
            Console.WriteLine("The new array is: ");
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];

                Console.Write(sum + " ");


            }
            Console.ReadLine();
        }
    }
}
