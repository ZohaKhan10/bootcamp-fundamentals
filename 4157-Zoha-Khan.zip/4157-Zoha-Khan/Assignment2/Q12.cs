﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q12
{
    class Program
    {
        static void Main(string[] args)
        {
          
            string input="who worries about curries";
            string output="";
            char[] arr=input.ToArray();
            
            for(int index=0; index<arr.Length; index++)
                {
             if( arr[index]=='i' && arr[index+1]=='e' && arr[index+2]=='s')
                    {
                    output=output+"s";
                    index=index+2;
                }
             else{
                    output=output+arr[index];
                }

            
            }

            Console.WriteLine(output);
            Console.ReadLine();

           
          
        }
    }
}
