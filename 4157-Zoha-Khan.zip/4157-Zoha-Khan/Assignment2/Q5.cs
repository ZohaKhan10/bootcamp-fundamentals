﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 4, 2, 4, 5, 2, 3, 1 };
            int size = arr.Length;
            Console.WriteLine("Repeated elements are:");
            for (int i = 0; i < size; i++)
            {

                for (int j = i + 1; j < size; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        Console.WriteLine(arr[i]);
                    }


                }
            }
            Console.ReadLine();
        }
    }
}
