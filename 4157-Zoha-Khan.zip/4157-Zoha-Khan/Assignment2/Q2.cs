﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = new int[10];
            int largest, secondLargest = 0;
            Console.WriteLine("Read elements of array");
            for (int i = 0; i < 10; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            largest = arr[0];

            for (int i = 0; i < 10; i++)
            {
                if (arr[i] > largest)
                {
                    largest = arr[i];
                }
            }
            Console.WriteLine("Largest element of array is:" + largest);

            //sorting of array
            for (int i = 0; i < 10; i++)
            {

                for (int j = i + 1; j < 10; j++)
                {
                    if (arr[j] < arr[i])
                    {
                        int temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;

                    }
                }

                secondLargest = arr[8];
            }
            Console.WriteLine("Second largest element of array is :" + secondLargest);

            Console.ReadLine();

        }
    }
}
